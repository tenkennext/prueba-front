module.exports = {
  devServer: {
    port: 3003/*8081*/
  },
  /*entry: {
    app: [
     './app/main.js'
    ]
  }*/
}